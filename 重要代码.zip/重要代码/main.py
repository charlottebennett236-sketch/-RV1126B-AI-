# ============================================================
# main.py - 主程序入口
# 职责：初始化各模块，启动所有线程和服务
# ============================================================

import time
import threading
from arm.robot_arm_driver import RobotArmDriver, SerialDriver
from config import SERIAL_PORT, SERIAL_BAUDRATE, SERIAL_TIMEOUT, INIT_JOINTS
import shared_state as state
from shared_state import log_lines, log_lock
from inference_thread import inference_thread
from arm_controller import arm_control_thread
from http_server import start_server


def log(msg):
    print(msg)
    ts = time.strftime('%H:%M:%S')
    with log_lock:
        log_lines.append(f"[{ts}] {msg}")
        if len(log_lines) > 80:
            log_lines.pop(0)


def main():
    # ── 初始化共享变量 ──
    state.current_joints = list(INIT_JOINTS)

    # ── 初始化机械臂 ──
    serial_driver = SerialDriver(
        port=SERIAL_PORT, baudrate=SERIAL_BAUDRATE, timeout=SERIAL_TIMEOUT)
    if not serial_driver.connect():
        log("[错误] 机械臂串口连接失败")
        return
    arm = RobotArmDriver(serial_driver)
    state.arm_instance = arm   # 供 http_server.py 的 reset 指令使用

    log("机械臂初始化...")
    arm.move_all_servos_by_angle([0, 0, 0, 0, 0], time_ms=2000)
    time.sleep(2.5)
    arm.move_all_servos_by_angle(INIT_JOINTS, time_ms=2000)
    time.sleep(2.5)
    log("初始化完成")

    # ── 启动推理线程 ──
    threading.Thread(target=inference_thread, daemon=True).start()
    log("等待摄像头就绪...")
    while True:
        with state.frame_lock:
            if state.latest_result_frame is not None:
                break
        time.sleep(0.1)
    log("摄像头就绪")

    # ── 启动机械臂控制线程 ──
    threading.Thread(
        target=arm_control_thread, args=(arm,), daemon=True).start()
    log("机械臂控制线程已启动")

    # ── 启动 HTTP 服务（主线程阻塞）──
    server = start_server()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log("退出中...")
    finally:
        serial_driver.disconnect()
        log("程序已退出")


if __name__ == "__main__":
    main()
