# ============================================================
# shared_state.py - 全局共享变量和锁
#
# 规则：
#   1. 所有共享变量只在这里定义，其他文件只允许 import
#   2. 每个变量注明：写入方、读取方、数据格式
#   3. 其他文件禁止在自己文件里定义新的共享变量
# ============================================================

import threading

# ─────────────────────────────────────────────
# 推理结果帧
# 写入方：inference_thread.py
# 读取方：http_server.py（视频流叠加显示）
# 格式：  numpy array (H, W, 3) BGR图像，未就绪时为 None
# ─────────────────────────────────────────────
latest_result_frame = None
frame_lock          = threading.Lock()

# ─────────────────────────────────────────────
# 检测框中心坐标列表
# 写入方：inference_thread.py（myFunc直接返回）
# 读取方：arm_controller.py（取目标坐标）
# 格式：  [(cx, cy), ...]，无目标时为空列表 []
# ─────────────────────────────────────────────
latest_centers = []
centers_lock   = threading.Lock()

# ─────────────────────────────────────────────
# 检测目标旋转角度列表
# 写入方：inference_thread.py（myFunc直接返回）
# 读取方：arm_controller.py（对中后旋转 J5 到对应角度）
# 格式：  [angle, ...]，与 latest_centers 一一对应
#         angle 单位：度，范围 0~90
#         0  = 物体竖放，夹爪不需要旋转
#         90 = 物体横放，夹爪需要旋转90度
#         无目标时为空列表 []
# ─────────────────────────────────────────────
latest_angles = []
angles_lock   = threading.Lock()

# ─────────────────────────────────────────────
# 机械臂运动状态
# 写入方：arm_controller.py、http_server.py（reset指令）
# 读取方：arm_controller.py、http_server.py（页面显示）
# 格式：  字符串，"idle" 或 "moving"
# ─────────────────────────────────────────────
arm_state      = "idle"
arm_state_lock = threading.Lock()

# ─────────────────────────────────────────────
# 当前关节角
# 写入方：arm_controller.py、http_server.py（reset指令）、main.py（初始化）
# 读取方：arm_controller.py、http_server.py（页面显示）、kinematics.py
# 格式：  [J1, J2, J3, J4, J5]，单位：度
# ─────────────────────────────────────────────
current_joints = []   # 由 main.py 初始化为 INIT_JOINTS
joints_lock    = threading.Lock()

# ─────────────────────────────────────────────
# 自动模式开关
# 写入方：http_server.py（toggle_auto指令）
# 读取方：arm_controller.py（判断是否自动触发移动）
# 格式：  bool，True=自动模式，False=手动模式
# ─────────────────────────────────────────────
auto_mode      = False
auto_mode_lock = threading.Lock()

# ─────────────────────────────────────────────
# 手动触发信号
# 写入方：http_server.py（grab指令置True）
# 读取方：arm_controller.py（读到True后执行移动，然后置False）
# 格式：  bool，True=触发一次移动
# ─────────────────────────────────────────────
manual_trigger      = False
manual_trigger_lock = threading.Lock()

# ─────────────────────────────────────────────
# 停止标志
# 写入方：http_server.py（stop指令置True）
# 读取方：arm_controller.py（检查是否停止）
# 格式：  bool，True=停止扫描，回到初始
# ─────────────────────────────────────────────
stopped      = False
stopped_lock = threading.Lock()

# ─────────────────────────────────────────────
# 实时检测信息（用于视频流叠加显示）
# 写入方：arm_controller.py
# 读取方：http_server.py（视频流叠加坐标信息）
# 格式：  None（无目标）或 dict：
#         {
#           "pixel":  (u, v),        # 像素坐标
#           "cam":    [X, Y, Z],     # 相机坐标系（mm）
#           "base":   [X, Y, Z],     # 基座坐标系（mm）
#           "stable": bool,          # 是否已稳定确认
#         }
# ─────────────────────────────────────────────
detection_info      = None
detection_info_lock = threading.Lock()

# ─────────────────────────────────────────────
# 日志缓存
# 写入方：log() 函数（所有模块调用）
# 读取方：http_server.py（/status接口返回给网页）
# 格式：  字符串列表，最多保留80条
# ─────────────────────────────────────────────
log_lines = []
log_lock  = threading.Lock()

# ─────────────────────────────────────────────
# 机械臂实例（供 http_server.py 的reset指令使用）
# 写入方：main.py（初始化时赋值）
# 读取方：http_server.py（reset指令调用move方法）
# 格式：  RobotArmDriver 实例，未初始化时为 None
# ─────────────────────────────────────────────
arm_instance = None