# ============================================================
# inference_thread.py - RKNN 推理线程
# 职责：摄像头读帧 → RKNN推理 → 写入共享变量
# ============================================================

import cv2
import time
from rknn.rknnpool.rknnpool_ld import rknnPoolExecutor
from rknn.func.func_yolov8_optimize_0430 import myFunc
from config import MODEL_PATH, TPEs, CAMERA_DEVICE, CAMERA_WIDTH, CAMERA_HEIGHT
import shared_state as state
from shared_state import log_lines, log_lock


def log(msg):
    print(msg)
    ts = time.strftime('%H:%M:%S')
    with log_lock:
        log_lines.append(f"[{ts}] {msg}")
        if len(log_lines) > 80:
            log_lines.pop(0)


def inference_thread():
    """
    推理线程主函数。

    流程：
        摄像头读帧
          → rknnPoolExecutor 多线程推理（myFunc）
          → myFunc 返回 (result_img, centers, angles)
          → 写入 latest_result_frame、latest_centers、latest_angles
    """
    cap = cv2.VideoCapture(CAMERA_DEVICE)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M','J','P','G'))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  CAMERA_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_HEIGHT)
    cap.set(cv2.CAP_PROP_BUFFERSIZE,   1)

    # 预热摄像头：丢弃前几帧，等待曝光稳定
    for _ in range(5):
        cap.read()

    pool = rknnPoolExecutor(rknnModel=MODEL_PATH, TPEs=TPEs, func=myFunc)

    # 预填充推理队列，让流水线满载运行
    if cap.isOpened():
        for _ in range(TPEs + 1):
            ret, frame = cap.read()
            if not ret:
                cap.release()
                del pool
                return
            pool.put(frame)

    frames, t0 = 0, time.time()

    while cap.isOpened():
        frames += 1
        ret, orig = cap.read()
        if not ret:
            break

        pool.put(orig)

        # myFunc 现在返回 (图像, centers, angles) 三元组
        # centers[i] 和 angles[i] 一一对应，表示同一个目标的坐标和角度
        result, flag = pool.get()
        if not flag:
            break
        result_img, centers, angles = result   # 拆包：图像、中心坐标列表、角度列表

        # 写入共享变量（加锁保护）
        with state.frame_lock:
            state.latest_result_frame = result_img.copy()
        with state.centers_lock:
            state.latest_centers = list(centers)
        with state.angles_lock:
            state.latest_angles = list(angles)   # 新增：写入角度列表

        # 每30帧打印一次帧率
        if frames % 30 == 0:
            log(f"推理帧率: {30 / (time.time() - t0):.1f} fps")
            t0 = time.time()

    cap.release()
    pool.release()