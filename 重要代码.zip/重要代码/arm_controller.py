# ============================================================
# arm_controller.py - 机械臂控制线程
# 职责：读取检测结果 → 视觉伺服对中 → 旋转J5对准物体短边 → 下压抓取
#
# 抓取流程：
#   1. 机械臂进入搜索姿态，J1 从左往右扫描
#   2. 发现目标且不在上边沿（距离合适），停止扫描
#   3. 视觉伺服对中
#   4. 跟丢时恢复到发现目标的角度，继续往右扫描
#   5. 扫完一整圈没找到，控制小车前进，重新扫描
#   6. 对中完成后读取物体角度，旋转 J5 对准物体短边
#   7. 用逆运动学下压到固定高度抓取（方案C）
# ============================================================

import time
import numpy as np
from config import (
    CONFIRM_FRAMES,
    INIT_JOINTS,
    VISUAL_SERVO_CENTER_THRESH,
    CAMERA_WIDTH, CAMERA_HEIGHT,
    GRAB_HEIGHT,
    IK_MAX_ERR,
    SEARCH_J2, SEARCH_J3, SEARCH_J4, SEARCH_J5,
    SCAN_J1_START, SCAN_J1_END, SCAN_J1_STEP,
    SCAN_WAIT_FRAMES, SCAN_V_MIN,
    CAR_SERIAL_PORT, CAR_SERIAL_BAUDRATE, CAR_SERIAL_PARITY,
    CAR_SERIAL_STOPBITS, CAR_SERIAL_BYTESIZE, CAR_SERIAL_TIMEOUT,
    CAR_MOVE_TIME, CAR_SPEED,
)
from kinematics import (
    calc_pixel_offset,
    pixel_offset_to_joint_delta,
    is_centered,
    forward_kinematics,
    inverse_kinematics,
)
import shared_state as state
from shared_state import log_lines, log_lock
from car.car import CarController

# 小车控制器实例
car_controller = CarController(
    port=CAR_SERIAL_PORT,
    baudrate=CAR_SERIAL_BAUDRATE,
    parity=CAR_SERIAL_PARITY,
    stopbits=CAR_SERIAL_STOPBITS,
    bytesize=CAR_SERIAL_BYTESIZE,
    timeout=CAR_SERIAL_TIMEOUT,
)

# 视觉伺服过程中，连续丢失目标超过此次数才判定为真正跟丢
SERVO_LOST_MAX = 5


def log(msg):
    print(msg)
    ts = time.strftime('%H:%M:%S')
    with log_lock:
        log_lines.append(f"[{ts}] {msg}")
        if len(log_lines) > 80:
            log_lines.pop(0)


# ─────────────────────────────────────────────
# 抓取后动作（用户自定义实现）
# ─────────────────────────────────────────────
def post_grab_action(arm):
    """
    抓取成功后执行的动作。
    用户可以在这里添加将物体放置到指定位置的逻辑。

    参数:
        arm: RobotArmDriver 实例
    """
    log("[动作] 执行抓取后动作（待用户实现）")
    # TODO: 用户添加放置物体的逻辑
    # 例如：移动到放置位置，打开夹爪等
    
    time.sleep(1.0)  # 占位时间
    arm.move_all_servos_by_angle([0, 15, 65, 0, 0], time_ms=2000)
    time.sleep(2.5)  # 占位时间
    log("张开夹爪...")
    arm.open_gripper(time_ms=500)
    time.sleep(2.0)  # 占位时间

def car_move_forward():
    """
    控制小车前进一段距离。

    小车控制采用时间控制方式：
        发送前进指令 → 等待固定时间 → 发送停止指令
    """
    try:
        log(f"[小车] 前进 {CAR_MOVE_TIME} 秒，速度 {CAR_SPEED}")
        
        # 发送前进指令：所有电机正转，速度相同
        car_controller.control_speed(CAR_SPEED, CAR_SPEED, CAR_SPEED, CAR_SPEED)
        
        # 等待前进时间
        time.sleep(CAR_MOVE_TIME)
        
        # 发送停止指令：所有电机速度为0
        car_controller.control_speed(0, 0, 0, 0)
        
        log("[小车] 前进完成，停止")
    except Exception as e:
        log(f"[小车] 前进失败: {e}")
        # 尝试停止电机
        try:
            car_controller.control_speed(0, 0, 0, 0)
        except:
            pass


# ─────────────────────────────────────────────
# 视觉伺服：调整关节角让物体移到图像中心
# ─────────────────────────────────────────────
def servo_adjust(arm, du, dv):
    """
    根据像素偏移量调整关节角，让摄像头对准物体。

    参数:
        arm: RobotArmDriver 实例
        du:  水平像素偏移（正=物体在图像右侧，末端需右转）
        dv:  垂直像素偏移（正=物体在图像下侧，末端需前伸）
    """
    dj1, dj2 = pixel_offset_to_joint_delta(du, dv)

    with state.joints_lock:
        joints = list(state.current_joints)

    joints[0] += dj1   # J1：控制左右方向
    joints[1] += dj2   # J2：控制前后方向

    joints[0] = float(np.clip(joints[0], -90, 90))
    joints[1] = float(np.clip(joints[1], -90, 90))

    log(f"[伺服] 偏移: du={du:.0f}px dv={dv:.0f}px  "
        f"调整: dJ1={dj1:.2f}° dJ2={dj2:.2f}°")

    arm.move_all_servos_by_angle(joints, time_ms=1000)
    time.sleep(1.1)

    with state.joints_lock:
        state.current_joints = joints


# ─────────────────────────────────────────────
# 旋转 J5 对准物体短边
# ─────────────────────────────────────────────
def rotate_j5_to_angle(arm, j5_angle):
    """
    对中完成后，旋转 J5 让夹爪对准物体短边方向。

    参数:
        arm:      RobotArmDriver 实例
        j5_angle: J5 需要旋转到的目标角度（度），范围 0~90
    """
    with state.joints_lock:
        joints = list(state.current_joints)

    joints[4] = float(np.clip(j5_angle, -90, 90))
    log(f"[旋转] J5 旋转到 {j5_angle:.1f}° 对准物体短边")

    arm.move_all_servos_by_angle(joints, time_ms=800)
    time.sleep(1.0)

    with state.joints_lock:
        state.current_joints = joints


# ─────────────────────────────────────────────
# 执行下压抓取动作（方案C：逆运动学下压到固定高度）
# ─────────────────────────────────────────────
def execute_grab(arm, j5_angle):
    """
    对中且旋转完成后，执行完整的抓取动作序列：
        1. 旋转 J5 对准物体短边
        2. 张开夹爪
        3. 逆运动学下压到物体所在平面高度
        4. 闭合夹爪
        5. 抬起回到对中时的高度

    注意：
        逆运动学只解 J1~J4，返回的 J5 固定为 0。
        下压时需要手动把 J5 改回 j5_angle，
        否则夹爪会在下压时转回原始方向。

    参数:
        arm:      RobotArmDriver 实例
        j5_angle: 物体对应的 J5 旋转角度（度）

    返回:
        True:  抓取成功
        False: IK误差过大，放弃
    """
    log("===== 开始抓取 =====")

    # ── 第一步：旋转 J5 对准物体短边 ──
    rotate_j5_to_angle(arm, j5_angle)

    with state.joints_lock:
        joints_centered = list(state.current_joints)

    # ── 第二步：正运动学获取当前末端位置 ──
    T = forward_kinematics(joints_centered)
    current_pos = T[:3, 3]

    log(f"对中后末端位置: x={current_pos[0]*1000:.1f} "
        f"y={current_pos[1]*1000:.1f} "
        f"z={current_pos[2]*1000:.1f} mm")

    # ── 第三步：构造下压目标位置 ──
    grab_pos = current_pos.copy()
    grab_pos[2] = GRAB_HEIGHT

    log(f"下压目标位置: x={grab_pos[0]*1000:.1f} "
        f"y={grab_pos[1]*1000:.1f} "
        f"z={grab_pos[2]*1000:.1f} mm")

    # ── 第四步：逆运动学求解下压关节角 ──
    joints_grab, err = inverse_kinematics(grab_pos, joints_centered)
    log(f"下压IK关节角(修正前): {[f'{j:.1f}' for j in joints_grab]}  误差: {err:.1f}mm")

    # 手动把 J5 改回旋转后的角度，防止下压时夹爪转回原始方向
    joints_grab[4] = j5_angle
    log(f"下压IK关节角(修正后): {[f'{j:.1f}' for j in joints_grab]}  J5={j5_angle:.1f}°保持不变")

    if err > IK_MAX_ERR:
        log(f"[抓取] IK误差过大 ({err:.1f}mm)，放弃抓取")
        return False

    # ── 第五步：张开夹爪 ──
    log("张开夹爪...")
    arm.open_gripper(time_ms=500)
    time.sleep(0.8)

    # ── 第六步：执行下压 ──
    log("下压中...")
    arm.move_all_servos_by_angle(joints_grab, time_ms=1500)
    time.sleep(2.0)

    with state.joints_lock:
        state.current_joints = joints_grab

    # ── 第七步：闭合夹爪 ──
    log("闭合夹爪...")
    arm.close_gripper(time_ms=500)
    time.sleep(0.8)

    # ── 第八步：抬起，J5 归零 ──
    joints_centered[4] = 0
    log("抬起中...")
    arm.move_all_servos_by_angle(joints_centered, time_ms=1500)
    time.sleep(2.0)

    with state.joints_lock:
        state.current_joints = joints_centered

    log("抓取完成 ✓")
    return True


# ─────────────────────────────────────────────
# J1 扫描搜索（支持从指定角度继续扫）
# ─────────────────────────────────────────────
def scan_for_target(arm, start_j1=None):
    """
    控制机械臂 J1 从指定角度往右扫描，寻找可抓取目标。

    支持从任意角度开始扫描：
        正常情况从 SCAN_J1_START 开始
        跟丢后从发现目标的角度继续往右扫

    参数:
        arm:      RobotArmDriver 实例
        start_j1: 扫描起始 J1 角度（度），None 则从 SCAN_J1_START 开始

    返回:
        (u, v, j5_angle, found_j1): 找到目标时返回像素坐标、角度、发现时的J1角度
        None:                       扫描完整个范围没找到合适目标
    """
    # 未指定起始角度则从头开始
    scan_start = start_j1 if start_j1 is not None else SCAN_J1_START

    log(f"===== 开始扫描搜索（起始J1={scan_start:.1f}°）=====")

    j1_positions = list(np.arange(scan_start, SCAN_J1_END + SCAN_J1_STEP,
                                  SCAN_J1_STEP))

    img_cx = CAMERA_WIDTH  // 2
    img_cy = CAMERA_HEIGHT // 2

    for j1 in j1_positions:
        # 检查停止信号
        with state.stopped_lock:
            if state.stopped:
                log("检测到停止信号，中断扫描")
                return None  # 中断扫描

        scan_joints = [
            float(j1),
            SEARCH_J2,
            SEARCH_J3,
            SEARCH_J4,
            SEARCH_J5,
        ]

        log(f"[扫描] J1={j1:.1f}°")

        arm.move_all_servos_by_angle(scan_joints, time_ms=800)
        time.sleep(1.0)

        with state.joints_lock:
            state.current_joints = scan_joints
        log(f"[扫描] {state.current_joints}")
        for _ in range(SCAN_WAIT_FRAMES):
            time.sleep(0.1)
            with state.stopped_lock:
                if state.stopped:
                    log("检测到停止信号，中断扫描等待")
                    return None

        with state.centers_lock:
            detections = list(state.latest_centers)
        with state.angles_lock:
            angles = list(state.latest_angles)

        if not detections:
            continue

        u, v = min(detections,
                   key=lambda p: abs(p[0] - img_cx) + abs(p[1] - img_cy))
        target_idx = detections.index((u, v))

        log(f"[扫描] 发现目标 像素=({u},{v})")

        if v < SCAN_V_MIN:
            log(f"[扫描] 目标太远（v={v} < {SCAN_V_MIN}），跳过")
            continue

        j5_angle = angles[target_idx] if target_idx < len(angles) else 0.0
        log(f"[扫描] 目标距离合适，停止  v={v}  j5={j5_angle:.1f}°  J1={j1:.1f}°")

        # 返回时多带一个 found_j1，跟丢后可以从这里继续扫
        return u, v, j5_angle, float(j1)

    log("===== 扫描完成，未找到合适目标 =====")
    return None


# ─────────────────────────────────────────────
# 机械臂控制线程主函数
# ─────────────────────────────────────────────
def arm_control_thread(arm):
    """
    机械臂控制线程主函数。

    状态机：
        idle      → 等待触发（手动 or 自动）
        scanning  → J1 扫描搜索目标
        serving   → 视觉伺服对中
        grabbing  → 旋转J5 + 执行抓取
        stopped   → 停止状态，不扫描

    跟丢处理：
        视觉伺服中连续丢失目标超过 SERVO_LOST_MAX 次
            → 恢复到发现目标时的 J1 角度
            → 从该角度继续往右扫描
            → 扫完一圈没找到 → 小车前进 → 重新从头扫描

    抓取后：
        执行 post_grab_action，然后从当前 J1 角度继续扫描
    """
    confirmed_count = 0
    MAX_SERVO_STEPS = 20
    start_j1 = None  # 扫描起始角度，None 表示从头开始

    # 主循环：持续监测触发状态，执行扫描 / 伺服 / 抓取流程
    while True:
        time.sleep(0.05)

        with state.stopped_lock:
            if state.stopped:
                continue

        with state.arm_state_lock:
            if state.arm_state in ["moving", "stopped"]:
                continue

        with state.auto_mode_lock:
            is_auto = state.auto_mode
        with state.manual_trigger_lock:
            triggered = state.manual_trigger

        if not (is_auto or triggered):
            continue

        if triggered:
            with state.manual_trigger_lock:
                state.manual_trigger = False

        with state.arm_state_lock:
            state.arm_state = "moving"

        # ══════════════════════════════════════
        # 主循环：扫描 → 伺服 → 抓取 → 动作 → 继续扫描
        # ══════════════════════════════════════
        while True:

                # 检查停止信号
                with state.stopped_lock:
                    if state.stopped:
                        log("检测到停止信号，中断扫描")
                        # 回到初始位置
                        arm.move_all_servos_by_angle([0, 0, 0, 0, 0], time_ms=3000)
                        time.sleep(3.5)
                        arm.move_all_servos_by_angle(INIT_JOINTS, time_ms=2000)
                        time.sleep(2.5)
                        with state.joints_lock:
                            state.current_joints = list(INIT_JOINTS)
                        with state.arm_state_lock:
                            state.arm_state = "stopped"
                        break  # 跳出扫描循环

                # ── 扫描搜索 ──
                log("===== 开始扫描 =====")
                scan_result = scan_for_target(arm, start_j1=start_j1)

                if scan_result is None:
                    with state.stopped_lock:
                        if state.stopped:
                            break
                    # 扫完一圈没找到 → 小车前进 → 重新从头扫描
                    log("扫描完成未找到目标，控制小车前进")
                    car_move_forward()
                    start_j1 = None  # 重置为从头开始
                    # 小车前进后重新从头扫描（外层 while True 继续）
                    continue

                scan_u, scan_v, j5_angle, found_j1 = scan_result

                # ── 视觉伺服对中 ──
                log("===== 开始视觉伺服对中 =====")
                servo_steps = 0
                lost_count  = 0
                grab_done   = False   # 标记是否成功完成抓取
                with state.joints_lock:
                    found_j1 = state.current_joints[0]   # ← 加这一行
                log(f"[伺服] 发现目标时 J1={found_j1:.1f}°")
                while True:
                    # 检查停止信号
                    with state.stopped_lock:
                        if state.stopped:
                            log("检测到停止信号，中断伺服")
                            # 回到初始位置
                            arm.move_all_servos_by_angle([0, 0, 0, 0, 0], time_ms=3000)
                            time.sleep(3.5)
                            arm.move_all_servos_by_angle(INIT_JOINTS, time_ms=2000)
                            time.sleep(2.5)
                            with state.joints_lock:
                                state.current_joints = list(INIT_JOINTS)
                            with state.arm_state_lock:
                                state.arm_state = "stopped"
                            break  # 跳出伺服循环

                    time.sleep(0.1)
                    with state.centers_lock:
                        detections = list(state.latest_centers)

                    if not detections:
                        # 目标暂时消失
                        lost_count += 1
                        log(f"[伺服] 目标暂时丢失 ({lost_count}/{SERVO_LOST_MAX})...")
                        if lost_count < SERVO_LOST_MAX:
                            time.sleep(0.1)
                            continue   # 继续等待

                        # ── 真正跟丢：恢复到发现时的角度，继续往右扫 ──
                        log(f"[伺服] 连续丢失 {SERVO_LOST_MAX} 次，跟丢！")
                        log(f"[伺服] 恢复到发现角度 J1={found_j1:.1f}°，继续扫描")

                        # 恢复到发现目标时的搜索姿态
                        recover_joints = [
                            found_j1,
                            SEARCH_J2, SEARCH_J3, SEARCH_J4, SEARCH_J5
                        ]
                        arm.move_all_servos_by_angle(recover_joints, time_ms=1000)
                        time.sleep(1.2)
                        with state.joints_lock:
                            state.current_joints = recover_joints

                        # 从发现角度的下一步继续往右扫
                        resume_j1  = found_j1 + SCAN_J1_STEP
                        log(f"[伺服] 从 J1={resume_j1:.1f}° 继续扫描")
                        scan_result = scan_for_target(arm, start_j1=resume_j1)

                        if scan_result is None:
                            # 剩余范围也没找到 → 小车前进 → 跳出伺服循环，重新从头扫
                            log("剩余范围未找到目标，控制小车前进")
                            car_move_forward()
                            start_j1 = None
                            break
                        else:
                            # 重新找到目标，更新扫描结果，继续伺服
                            scan_u, scan_v, j5_angle, found_j1 = scan_result
                            log(f"[扫描] 重新找到目标 J1={found_j1:.1f}°")
                            lost_count  = 0
                            servo_steps = 0
                            continue

                    # 找到目标，重置丢失计数
                    lost_count = 0
                    img_cx = CAMERA_WIDTH  // 2
                    img_cy = CAMERA_HEIGHT // 2
                    u, v   = min(detections,
                                key=lambda p: abs(p[0] - img_cx) + abs(p[1] - img_cy))
                    target_idx = detections.index((u, v))
                    du, dv = calc_pixel_offset(u, v)

                    with state.detection_info_lock:
                        state.detection_info = {
                            "pixel":  (u, v),
                            "du":     du,
                            "dv":     dv,
                            "stable": confirmed_count >= CONFIRM_FRAMES,
                            "cam":    np.array([du, dv, 0]),
                            "base":   np.array([du, dv, 0]),
                        }
                    u, v   = min(detections,
                                 key=lambda p: abs(p[0] - img_cx) + abs(p[1] - img_cy))
                    du, dv = calc_pixel_offset(u, v)

                    log(f"[伺服] 当前位置: ({u},{v})  偏移: du={du} dv={dv}")

                    if is_centered(du, dv):
                        log("[伺服] 对中完成 ✓")

                        target_idx = detections.index((u, v))
                        with state.angles_lock:
                            angles = list(state.latest_angles)
                        j5_angle = angles[target_idx] if target_idx < len(angles) else 0.0
                        log(f"[旋转] 目标物体角度: {j5_angle:.1f}°")

                        execute_grab(arm, j5_angle)
                        grab_done = True
                        break

                    if servo_steps >= MAX_SERVO_STEPS:
                        log(f"[伺服] 超过最大调整次数 {MAX_SERVO_STEPS}，放弃")
                        break

                    servo_adjust(arm, du, dv)
                    servo_steps += 1

                # 抓取完成，执行后动作，然后从当前 J1 继续扫描
                if grab_done:
                    post_grab_action(arm)
                    with state.joints_lock:
                        current_j1 = state.current_joints[0]
                    start_j1 = current_j1  # 从当前 J1 继续扫描
                    continue  # 继续外层循环，重新扫描

        # 恢复 idle（如果需要的话，但现在不会到达这里）
        confirmed_count = 0
        with state.arm_state_lock:
            state.arm_state = "idle"
        log("===== 等待下一次触发 =====")