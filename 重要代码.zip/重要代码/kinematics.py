# ============================================================
# kinematics.py - 运动学计算 & 坐标变换
# 包含：正运动学、逆运动学、像素坐标反投影、坐标系变换
#       视觉伺服相关计算（像素偏移→关节角调整）
# ============================================================

import math
import numpy as np
from config import (
    DH_PARAMS, IK_TOL, IK_MAX_ITER,
    PLANE_Z_IN_CAM, CAMERA_K_PATH, CAMERA_DIST_PATH,
    HAND_EYE_R_PATH, HAND_EYE_T_PATH,
    CAMERA_WIDTH, CAMERA_HEIGHT,
    VISUAL_SERVO_SCALE_U, VISUAL_SERVO_SCALE_V,
    VISUAL_SERVO_CENTER_THRESH
)

# ─────────────────────────────────────────────
# 加载标定文件
# ─────────────────────────────────────────────
K    = np.load(CAMERA_K_PATH)
dist = np.load(CAMERA_DIST_PATH)
R_he = np.load(HAND_EYE_R_PATH)
t_he = np.load(HAND_EYE_T_PATH)

# 构建相机→末端齐次变换矩阵 (4×4)
T_cam2gripper = np.eye(4)
T_cam2gripper[:3, :3] = R_he
T_cam2gripper[:3,  3] = t_he.flatten()


# ─────────────────────────────────────────────
# 正运动学
# ─────────────────────────────────────────────
def dh_matrix(alpha, a, d, theta):
    """构造单个关节的 DH 齐次变换矩阵。"""
    ct, st = math.cos(theta), math.sin(theta)
    ca, sa = math.cos(alpha), math.sin(alpha)
    return np.array([
        [ct, -st*ca,  st*sa, a*ct],
        [st,  ct*ca, -ct*sa, a*st],
        [ 0,     sa,     ca,    d],
        [ 0,      0,      0,    1]
    ])

def forward_kinematics(angles_deg):
    """
    正运动学：输入各关节角度（度），返回末端齐次变换矩阵 (4×4)。

    参数:
        angles_deg: 5个关节角度列表（度）

    返回:
        T: 4×4 齐次变换矩阵，T[:3,3] 是末端位置（米）
    """
    T = np.eye(4)
    for i, q in enumerate(angles_deg):
        alpha, a, d, offset = DH_PARAMS[i]
        T = T @ dh_matrix(alpha, a, d, math.radians(q) + offset)
    return T


# ─────────────────────────────────────────────
# 逆运动学（数值法，只解 J1~J4，J5 固定为 0）
# ─────────────────────────────────────────────
def inverse_kinematics(target_pos, init_joints):
    """
    数值迭代逆运动学。

    参数:
        target_pos:  目标位置 [x, y, z]（基座坐标系，米）
        init_joints: 初始关节角列表（5个，度）

    返回:
        result:    5个关节角（度），J5 固定为 0
        final_err: 末端位置误差（毫米）
    """
    joints = np.array(init_joints[:4], dtype=float)

    for _ in range(IK_MAX_ITER):
        T   = forward_kinematics(joints.tolist() + [0])
        pos = T[:3, 3]
        err = np.array(target_pos) - pos
        if np.linalg.norm(err) < IK_TOL:
            break

        # 数值雅可比矩阵（对 J1~J4 各扰动 0.1°）
        J = np.zeros((3, 4))
        for j in range(4):
            jd = joints.copy()
            jd[j] += 0.1
            J[:, j] = (forward_kinematics(jd.tolist() + [0])[:3, 3] - pos) \
                      / math.radians(0.1)

        # 伪逆更新关节角
        joints += np.degrees(np.linalg.pinv(J) @ err) * 0.5

        # 关节限位保护
        for j, (lo, hi) in enumerate([(-90, 90)] * 4):
            joints[j] = np.clip(joints[j], lo, hi)

    result    = joints.tolist() + [0]
    final_err = np.linalg.norm(
        np.array(target_pos) - forward_kinematics(result)[:3, 3]) * 1000
    return result, final_err


# ─────────────────────────────────────────────
# 坐标变换（原有方案保留，备用）
# ─────────────────────────────────────────────
def pixel_to_camera_coords(u, v):
    """
    固定平面反投影：像素坐标 → 相机坐标系 3D 坐标。
    利用物体在固定平面（Z=PLANE_Z_IN_CAM）的约束，
    不需要深度相机，不需要知道物体大小。

    参数:
        u, v: 检测框中心像素坐标

    返回:
        np.array([X, Y, Z])，单位米，相机坐标系
    """
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]
    z = PLANE_Z_IN_CAM
    return np.array([(u - cx) * z / fx,
                     (v - cy) * z / fy,
                     z])

def camera_to_base(point_cam, joints_deg):
    """
    相机坐标系 → 基座坐标系。

    变换链：
        相机坐标系
          → (T_cam2gripper，手眼标定) →
        末端坐标系
          → (forward_kinematics，正运动学) →
        基座坐标系

    参数:
        point_cam:  相机坐标系下的 3D 点 [X, Y, Z]（米）
        joints_deg: 当前关节角列表（5个，度）

    返回:
        np.array([X, Y, Z])，基座坐标系，单位米
    """
    p = np.append(point_cam, 1.0)
    return (forward_kinematics(joints_deg) @ T_cam2gripper @ p)[:3]


# ─────────────────────────────────────────────
# 视觉伺服计算（新方案）
# ─────────────────────────────────────────────
def calc_pixel_offset(u, v):
    """
    计算物体当前像素坐标相对于图像中心的偏移量。

    图像中心是摄像头光轴投影点，物体到达图像中心时，
    说明摄像头（末端）正对着物体，此时可以执行下压抓取。

    参数:
        u, v: 物体检测框中心像素坐标

    返回:
        du: 水平偏移（像素），正数=物体在图像右侧，需要末端向右移
        dv: 垂直偏移（像素），正数=物体在图像下侧，需要末端向前移
    """
    # 图像中心坐标
    center_u = CAMERA_WIDTH  // 2   # 640//2 = 320
    center_v = CAMERA_HEIGHT // 2   # 480//2 = 240

    du = u - center_u   # 物体相对图像中心的水平偏移
    dv = v - center_v   # 物体相对图像中心的垂直偏移
    return du, dv


def pixel_offset_to_joint_delta(du, dv):
    """
    将图像中的像素偏移量转换为关节角调整量。

    原理：
        摄像头装在末端，图像中物体偏右，说明末端需要向右转（J1增大）
        图像中物体偏下，说明末端需要向前伸（J2减小）
        比例系数 VISUAL_SERVO_SCALE 需要通过实验标定：
            让机械臂移动固定角度，观察图像中物体偏移了多少像素，
            scale = 角度变化量 / 像素变化量

    参数:
        du: 水平像素偏移（正=右）
        dv: 垂直像素偏移（正=下）

    返回:
        dj1: J1 关节角调整量（度），控制左右方向
        dj2: J2 关节角调整量（度），控制前后方向
    """
    # VISUAL_SERVO_SCALE_U：水平方向，每个像素对应的J1调整角度
    # VISUAL_SERVO_SCALE_V：垂直方向，每个像素对应的J2调整角度
    # 注意符号：du为正（物体在右）→ J1需要增大（末端右转）
    #           dv为正（物体在下）→ J2需要减小（末端前伸），所以取负
    dj1 =  du * VISUAL_SERVO_SCALE_U
    dj2 = -dv * VISUAL_SERVO_SCALE_V
    return dj1, dj2


def is_centered(du, dv):
    """
    判断物体是否已经对中（在图像中心附近）。
    对中后才能执行下压抓取动作。

    参数:
        du: 水平像素偏移
        dv: 垂直像素偏移

    返回:
        bool: True=已对中可以抓取，False=还需要继续调整
    """
    # VISUAL_SERVO_CENTER_THRESH：对中误差阈值（像素）
    # 误差在阈值内认为对中完成
    return abs(du) < VISUAL_SERVO_CENTER_THRESH and \
           abs(dv) < VISUAL_SERVO_CENTER_THRESH