# ============================================================
# http_server.py - HTTP 服务
# 职责：控制页面、MJPEG视频流、JSON状态接口、控制指令接口
# 单端口（8080），ThreadingHTTPServer 让每个请求独立线程处理
# ============================================================

import cv2
import time
import threading
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, parse_qs
from config import BOARD_IP, PORT, INIT_JOINTS
import shared_state as state
from shared_state import log_lines, log_lock


def log(msg):
    print(msg)
    ts = time.strftime('%H:%M:%S')
    with log_lock:
        log_lines.append(f"[{ts}] {msg}")
        if len(log_lines) > 80:
            log_lines.pop(0)


# ─────────────────────────────────────────────
# 多线程HTTP服务器
# ThreadingMixIn：每个请求开一个新线程
# 视频流（长连接）不会阻塞按钮的fetch请求
# ─────────────────────────────────────────────
class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True   # 主线程退出时子线程自动结束


# ─────────────────────────────────────────────
# 合并Handler：所有路径统一处理
# ─────────────────────────────────────────────
class MergedHandler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass   # 屏蔽HTTP请求日志

    def do_GET(self):
        parsed = urlparse(self.path)
        path   = parsed.path

        if path == '/':
            self._page()
        elif path == '/video':
            self._video()
        elif path == '/status':
            self._status()
        elif path == '/cmd':
            self._cmd(parse_qs(parsed.query))
        else:
            self.send_response(404)
            self.end_headers()

    # ─────────────────────────────────────────
    # 控制页面
    # ─────────────────────────────────────────
    def _page(self):
        """
        控制页面：
        1. <img src="/video"> 同端口同源，浏览器不会拦截
        2. 按钮 fetch 访问 /cmd，和视频流在同一端口
        3. ThreadingHTTPServer 保证两者互不阻塞
        4. setInterval 每秒局部更新状态，页面不整体刷新
        """
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.end_headers()

        html = f'''<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<title>机械臂控制</title>
<style>
  *    {{ box-sizing:border-box; margin:0; padding:0; }}
  body {{ background:#141414; color:#e0e0e0; font-family:'Courier New',monospace;
          display:flex; flex-direction:column; align-items:center;
          padding:16px; gap:12px; }}
  h2   {{ color:#4fc3f7; font-size:18px; letter-spacing:2px; }}
  #video-wrap {{ position:relative; width:100%; max-width:640px; }}
  #video-wrap img {{ width:100%; border-radius:6px;
    border:2px solid #263238; display:block; }}
  #overlay {{ position:absolute; top:8px; right:8px;
    background:rgba(0,0,0,.55); padding:4px 8px;
    border-radius:4px; font-size:12px; color:#80cbc4; }}
  .panel {{ display:flex; gap:10px; width:100%; max-width:640px; }}
  .card  {{ background:#1e1e1e; border:1px solid #2a2a2a;
    border-radius:6px; padding:12px; flex:1; }}
  .card h3 {{ color:#90a4ae; font-size:12px;
    text-transform:uppercase; margin-bottom:8px; }}
  .badge {{ display:inline-block; padding:2px 8px;
    border-radius:10px; font-size:13px; font-weight:bold; }}
  .badge-idle   {{ background:#1b5e20; color:#a5d6a7; }}
  .badge-moving {{ background:#e65100; color:#ffccbc; }}
  .badge-stopped {{ background:#d32f2f; color:#ffcdd2; }}
  .btns {{ display:flex; flex-direction:column; gap:8px; min-width:140px; }}
  button {{ padding:10px 0; border:none; border-radius:5px;
    cursor:pointer; font-size:13px; font-weight:bold;
    letter-spacing:1px; transition:opacity .15s; }}
  button:active   {{ opacity:.7; }}
  button:disabled {{ opacity:.4; cursor:default; }}
  .btn-grab        {{ background:#2e7d32; color:#fff; }}
  .btn-reset       {{ background:#e65100; color:#fff; }}
  .btn-auto        {{ background:#1565c0; color:#fff; }}
  .btn-auto.on     {{ background:#0288d1; }}
  .btn-stop        {{ background:#d32f2f; color:#fff; }}
  .btn-start       {{ background:#388e3c; color:#fff; }}
  /* 夹爪控制按钮：两个并排显示 */
  .gripper-row     {{ display:flex; gap:6px; }}
  .btn-open        {{ background:#6a1b9a; color:#fff; flex:1; }}
  .btn-close       {{ background:#37474f; color:#fff; flex:1; }}
  #logbox {{ width:100%; max-width:640px; background:#0d0d0d;
    border:1px solid #1e1e1e; border-radius:6px; padding:10px;
    height:160px; overflow-y:auto; font-size:11px; color:#78909c;
    white-space:pre-wrap; line-height:1.6; }}
</style>
</head>
<body>
<h2>▣ 机械臂视觉控制系统</h2>

<div id="video-wrap">
  <img src="/video" alt="视频加载中...">
  <div id="overlay">● LIVE</div>
</div>

<div class="panel">
  <!-- 状态卡片 -->
  <div class="card">
    <h3>系统状态</h3>
    <p>机械臂：<span id="arm-badge" class="badge badge-idle">idle</span></p>
    <br>
    <p style="font-size:12px;color:#546e7a">自动模式</p>
    <p id="auto-state" style="font-size:13px;color:#4fc3f7">关闭</p>
    <br>
    <p style="font-size:12px;color:#546e7a">关节角</p>
    <p id="joints" style="font-size:11px;color:#80cbc4">-</p>
  </div>

  <!-- 操作按钮 -->
  <div class="card btns">
    <h3>操作</h3>
    <button class="btn-grab"  id="btn-grab"  onclick="grab()">▶ 立即抓取</button>
    <button class="btn-reset" id="btn-reset" onclick="reset()">↺ 回初始位</button>
    <button class="btn-auto"  id="btn-auto"  onclick="toggleAuto()">自动模式：关</button>
    <button class="btn-stop"  id="btn-stop"  onclick="stop()">⏹ 停止</button>
    <button class="btn-start" id="btn-start" onclick="start()">▶ 开始</button>
    <!-- 夹爪控制：张开和闭合并排 -->
    <div class="gripper-row">
      <button class="btn-open"  id="btn-open"  onclick="gripperOpen()">✋ 张开</button>
      <button class="btn-close" id="btn-close" onclick="gripperClose()">✊ 闭合</button>
    </div>
  </div>
</div>

<div id="logbox">等待日志输出...</div>

<script>
function setLoading(id, on) {{
  const btn = document.getElementById(id);
  if (btn) btn.disabled = on;
}}
async function cmd(action) {{
  try {{
    const r = await fetch('/cmd?action=' + action);
    return await r.json();
  }} catch(e) {{
    appendLog('[前端] 请求失败: ' + e);
    return {{}};
  }}
}}
async function grab() {{
  setLoading('btn-grab', true);
  appendLog('[操作] 发送抓取指令...');
  await cmd('grab');
  setLoading('btn-grab', false);
}}
async function reset() {{
  setLoading('btn-reset', true);
  appendLog('[操作] 发送回位指令...');
  await cmd('reset');
  setLoading('btn-reset', false);
}}
async function toggleAuto() {{
  const d = await cmd('toggle_auto');
  updateAutoBtn(d.auto_mode);
}}
async function stop() {{
  setLoading('btn-stop', true);
  appendLog('[操作] 发送停止指令...');
  await cmd('stop');
  setLoading('btn-stop', false);
}}
async function start() {{
  setLoading('btn-start', true);
  appendLog('[操作] 发送开始指令...');
  await cmd('start');
  setLoading('btn-start', false);
}}
// 夹爪张开
async function gripperOpen() {{
  setLoading('btn-open', true);
  appendLog('[操作] 夹爪张开...');
  await cmd('gripper_open');
  setLoading('btn-open', false);
}}
// 夹爪闭合
async function gripperClose() {{
  setLoading('btn-close', true);
  appendLog('[操作] 夹爪闭合...');
  await cmd('gripper_close');
  setLoading('btn-close', false);
}}
function updateAutoBtn(on) {{
  const btn = document.getElementById('btn-auto');
  btn.textContent = '自动模式：' + (on ? '开' : '关');
  btn.classList.toggle('on', on);
}}
function appendLog(line) {{
  const box = document.getElementById('logbox');
  box.textContent += '\\n' + line;
  box.scrollTop = box.scrollHeight;
}}
async function pollStatus() {{
  try {{
    const r = await fetch('/status');
    const d = await r.json();
    const badge = document.getElementById('arm-badge');
    badge.textContent = d.arm_state;
    badge.className = 'badge ' +
      (d.arm_state === 'idle' ? 'badge-idle' : 'badge-moving');
    if (d.stopped) {{
      badge.className = 'badge-stopped';
      badge.textContent = 'stopped';
    }}
    document.getElementById('auto-state').textContent =
      d.auto_mode ? '开启' : '关闭';
    updateAutoBtn(d.auto_mode);
    document.getElementById('joints').textContent = d.joints;
    const box = document.getElementById('logbox');
    const prev = box._lastLogCount || 0;
    if (d.logs.length > prev) {{
      d.logs.slice(prev).forEach(l => {{ box.textContent += '\\n' + l; }});
      box._lastLogCount = d.logs.length;
      box.scrollTop = box.scrollHeight;
    }}
  }} catch(e) {{}}
}}
setInterval(pollStatus, 1000);
pollStatus();
</script>
</body>
</html>'''
        self.wfile.write(html.encode('utf-8'))

    # ─────────────────────────────────────────
    # MJPEG 视频流
    # ─────────────────────────────────────────
    def _video(self):
        """推送 MJPEG 视频流，每帧叠加状态和检测坐标信息。"""
        self.send_response(200)
        self.send_header('Content-type',
                         'multipart/x-mixed-replace; boundary=frame')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

        while True:
            with state.frame_lock:
                frame = state.latest_result_frame

            if frame is None:
                time.sleep(0.05)
                continue

            display = frame.copy()
            with state.arm_state_lock:  cur_state = state.arm_state
            with state.auto_mode_lock:  is_auto   = state.auto_mode
            with state.stopped_lock:    is_stopped = state.stopped

            # 第一行：模式 & 机械臂状态
            state_color = (0, 255, 0) if cur_state == 'idle' else (0, 140, 255)
            if is_stopped:
                state_color = (0, 0, 255)
            cv2.putText(display,
                f"{'[AUTO]' if is_auto else '[MANUAL]'}  {cur_state.upper()} {'[STOPPED]' if is_stopped else ''}",
                (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.65, state_color, 2)

            # 实时检测位置信息
            with state.detection_info_lock:
                info = state.detection_info

            if info is not None:
                px, py     = info["pixel"]
                cx, cy, cz = info["cam"]
                bx, by, bz = info["base"]
                stable     = info["stable"]

                cross_color = (0, 255, 255) if stable else (0, 165, 255)
                cv2.drawMarker(display, (px, py), cross_color,
                               cv2.MARKER_CROSS, 20, 2)
                cv2.putText(display,
                    "LOCKED" if stable else "DETECTING...",
                    (px + 12, py - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, cross_color, 1)

                panel_lines = [
                    f"Pixel : ({px}, {py})",
                    f"Camera: X={cx:+.1f} Y={cy:+.1f} Z={cz:.1f} mm",
                    f"Base  : X={bx:+.1f} Y={by:+.1f} Z={bz:.1f} mm",
                ]
                fh      = 18
                panel_h = fh * len(panel_lines) + 10
                panel_y = display.shape[0] - panel_h - 25

                overlay = display.copy()
                cv2.rectangle(overlay, (6, panel_y - 4),
                              (310, panel_y + panel_h), (0, 0, 0), -1)
                cv2.addWeighted(overlay, 0.5, display, 0.5, 0, display)

                for i, line in enumerate(panel_lines):
                    cv2.putText(display, line,
                        (10, panel_y + i * fh + fh - 2),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
            else:
                cv2.putText(display, "No target detected",
                    (10, display.shape[0] - 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (80, 80, 80), 1)

            # 最底行：关节角
            with state.joints_lock:
                joints = list(state.current_joints)
            joints_str = " ".join(
                [f"J{i+1}:{v:.0f}" for i, v in enumerate(joints)])
            cv2.putText(display, joints_str,
                (10, display.shape[0] - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (120, 120, 120), 1)

            ret, jpeg = cv2.imencode(
                '.jpg', display, [cv2.IMWRITE_JPEG_QUALITY, 75])
            if not ret:
                continue

            try:
                self.wfile.write(b'--frame\r\n')
                self.wfile.write(b'Content-Type: image/jpeg\r\n\r\n')
                self.wfile.write(jpeg.tobytes())
                self.wfile.write(b'\r\n')
            except Exception:
                break   # 客户端断开连接

    # ─────────────────────────────────────────
    # JSON 状态接口
    # ─────────────────────────────────────────
    def _status(self):
        with state.arm_state_lock:  cur_state = state.arm_state
        with state.auto_mode_lock:  is_auto   = state.auto_mode
        with state.stopped_lock:    is_stopped = state.stopped
        with state.joints_lock:     joints    = list(state.current_joints)
        with log_lock:              logs      = list(log_lines)

        joints_str = " ".join(
            [f"J{i+1}={v:.1f}" for i, v in enumerate(joints)])

        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps({
            "arm_state": cur_state,
            "auto_mode": is_auto,
            "stopped":   is_stopped,
            "joints":    joints_str,
            "logs":      logs,
        }).encode())

    # ─────────────────────────────────────────
    # 控制指令接口
    # ─────────────────────────────────────────
    def _cmd(self, params):
        action = params.get('action', [''])[0]
        result = {"ok": True}

        if action == 'grab':
            # 触发一次抓取流程
            with state.manual_trigger_lock:
                state.manual_trigger = True
            log("[HTTP] 手动抓取指令")

        elif action == 'reset':
            # 在独立线程里执行回位，避免阻塞HTTP响应
            def do_reset():
                with state.arm_state_lock:
                    state.arm_state = "moving"
                log("执行回位...")
                state.arm_instance.move_all_servos_by_angle(
                    [0, 0, 0, 0, 0], time_ms=3000)
                time.sleep(3.5)
                state.arm_instance.move_all_servos_by_angle(
                    INIT_JOINTS, time_ms=2000)
                time.sleep(2.5)
                with state.joints_lock:
                    state.current_joints = list(INIT_JOINTS)
                log("已回到初始姿态")
                with state.arm_state_lock:
                    state.arm_state = "idle"
            threading.Thread(target=do_reset, daemon=True).start()

        elif action == 'toggle_auto':
            # 切换自动/手动模式
            with state.auto_mode_lock:
                state.auto_mode = not state.auto_mode
                result["auto_mode"] = state.auto_mode
            log(f"[HTTP] 自动模式: {'开' if state.auto_mode else '关'}")

        elif action == 'stop':
            # 停止扫描，回到初始位置
            with state.stopped_lock:
                state.stopped = True
            with state.arm_state_lock:
                if state.arm_state != "stopped":
                    state.arm_state = "stopped"
            # 执行回位
            def do_stop():
                log("执行停止，回位...")
                state.arm_instance.move_all_servos_by_angle(
                    [0, 0, 0, 0, 0], time_ms=3000)
                time.sleep(3.5)
                state.arm_instance.move_all_servos_by_angle(
                    INIT_JOINTS, time_ms=2000)
                time.sleep(2.5)
                with state.joints_lock:
                    state.current_joints = list(INIT_JOINTS)
                log("已停止并回到初始姿态")
                with state.arm_state_lock:
                    state.arm_state = "stopped"
            threading.Thread(target=do_stop, daemon=True).start()

        elif action == 'start':
            # 开始扫描
            with state.stopped_lock:
                if state.stopped:
                    state.stopped = False
                    with state.manual_trigger_lock:
                        state.manual_trigger = True
                    with state.arm_state_lock:
                        state.arm_state = "idle"
                    log("[HTTP] 开始扫描")
                else:
                    log("[HTTP] 已在运行中")

        elif action == 'gripper_open':
            # 夹爪张开，在独立线程里执行，不阻塞HTTP响应
            def do_open():
                log("[HTTP] 夹爪张开")
                state.arm_instance.open_gripper(time_ms=500)
            threading.Thread(target=do_open, daemon=True).start()

        elif action == 'gripper_close':
            # 夹爪闭合，在独立线程里执行，不阻塞HTTP响应
            def do_close():
                log("[HTTP] 夹爪闭合")
                state.arm_instance.close_gripper(time_ms=500)
            threading.Thread(target=do_close, daemon=True).start()

        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(result).encode())


def start_server():
    """启动 HTTP 服务，阻塞直到退出。"""
    server = ThreadingHTTPServer(('0.0.0.0', PORT), MergedHandler)
    log(f"服务已启动 → http://{BOARD_IP}:{PORT}")
    log("默认手动模式，点击【立即抓取】触发，或开启自动模式")
    return server